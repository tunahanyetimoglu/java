
public class De�i�kenler 
{	
	public static void main(String[] args) 
	{
		String x="5";
		int a=Integer.valueOf(x);
		System.out.println(a*a);
		
		
		double sayi1=39.6;
		int sayi2=(int)sayi1;
		
		float sayi3=567.5f;
		byte sayi4=(byte) sayi3;
	}

}
