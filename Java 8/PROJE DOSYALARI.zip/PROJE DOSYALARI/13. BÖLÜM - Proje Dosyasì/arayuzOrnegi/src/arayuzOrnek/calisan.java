package arayuzOrnek;

public interface calisan {
	double calisanSabiti = 0.7;
	void bolumYazdir();
	void ucretBelirle(double ucret);
	double ucret();
}
