package arayuzOrnek;

public interface pazarlamaKom extends calisan {
	final double komSabit = 0.2;

	public void komBelirle(int adet);
}
