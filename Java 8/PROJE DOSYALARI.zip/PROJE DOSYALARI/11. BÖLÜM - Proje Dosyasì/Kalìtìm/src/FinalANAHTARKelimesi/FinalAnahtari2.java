package FinalANAHTARKelimesi;

class A
{
	public final void metod1()
	{
		System.out.println("Buras� A s�n�f�nda tan�mlanm�� metod");
	}
}

class B extends A
{
	/*public void metod1()
	{
		System.out.println("Bu metod override edilemez");
	}*/
}

public class FinalAnahtari2 {
	
	public static void main(String[] args) 
	{

	}

}
