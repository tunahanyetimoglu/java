package FinalANAHTARKelimesi;

public class FinalAnahtari 
{
	private final int a;
	
	public FinalAnahtari(int x)
	{
		a=x;
	}
	
	public static void main(String[] args) 
	{
		FinalAnahtari f1=new FinalAnahtari(6);
		final int b;
		b=10;
		
	}

}
