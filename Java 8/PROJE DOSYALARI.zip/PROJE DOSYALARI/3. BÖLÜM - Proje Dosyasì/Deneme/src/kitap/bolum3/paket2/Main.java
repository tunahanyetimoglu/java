package kitap.bolum3.paket2;

public class Main 
{
	public static void main(String[] args)
	{
		System.out.println("Paket Kavram� Anlat�l�yor");
	}
}
