package kitap.bolum3.paket1;


public class HelloWorld 
{
	public static void main(String[] java)
	{
		System.out.println("Merhaba D�nya");
		System.out.println("Java'ya D�nyas�na Ho�geldiniz");
		
		System.out.println(Math.pow(5,2));
		
	}
}
