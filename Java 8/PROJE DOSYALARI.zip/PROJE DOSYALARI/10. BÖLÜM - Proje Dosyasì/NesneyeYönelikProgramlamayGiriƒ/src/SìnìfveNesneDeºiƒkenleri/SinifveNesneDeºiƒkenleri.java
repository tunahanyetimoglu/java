package S�n�fveNesneDe�i�kenleri;

public class SinifveNesneDe�i�kenleri
{
	 static String ad;
	
	static String adVer()
	{
		return ad;
	}
	
	public static void main(String[] args) 
	{
		SinifveNesneDe�i�kenleri.ad="Mehmet";
		
		System.out.println(SinifveNesneDe�i�kenleri.adVer());
	}

}
