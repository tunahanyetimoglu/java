package Kaps�lleme2;

import Kaps�lleme.PublicAnahtari;

public class PublicAnahtari2 

{
	public static void main(String[] args) 
	{
		PublicAnahtari nesne2=new PublicAnahtari();
		nesne2.gizlimetod();
	}
}
