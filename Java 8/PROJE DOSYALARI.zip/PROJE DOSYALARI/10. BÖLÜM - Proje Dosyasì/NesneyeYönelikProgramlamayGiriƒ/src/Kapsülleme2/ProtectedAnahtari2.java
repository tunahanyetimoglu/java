package Kaps�lleme2;

import Kaps�lleme.ProtectedAnahtari;

public class ProtectedAnahtari2 {

	public static void main(String[] args) 
	{
		ProtectedAnahtari nesne2=new ProtectedAnahtari();
		//nesne2.gizlide�i�ken;
		//nesne2.gizlimetod;
	}

}
