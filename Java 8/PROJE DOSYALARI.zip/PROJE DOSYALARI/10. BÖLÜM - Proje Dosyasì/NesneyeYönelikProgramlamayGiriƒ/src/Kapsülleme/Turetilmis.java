package Kaps�lleme;

public class Turetilmis extends ProtectedAnahtari{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Turetilmis t1=new Turetilmis();
		t1.gizlimetod();

	}

}
