package aciklama;

public class olayOrnek {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

/*ActionEvent

ActionEvent(Object kaynak,int id,String komut)
getActionCommand()
getModifiers()
getWhen()
paramString()

AdjustmentEvent

getAdjustable()
getAdjustmentType()
getValue()
getValueIsAdjusting()

ComponentEvent

getComponent()

ConatinerEvent

ContainerEvent(kaynak,id,diger)
getContainer()
getChild()

FocusEvent

getOppositeComponent()
isTemproray()

InputEvent

isAltDown()
isAltGraphDown()
isControlDown()
isShiftDown()
isMetaDown()
getModifiers()

ItemEvent

getItem()
getItemSelectable()
getStateChange()

SELECTED
DESELECTED
ITEM_STATE_CHANGE

KeyEvent

KEY_PRESSED
KEY_RELEASED
KEY_TYPED
VK_ENTER
VK_CAPS_LOCK
VK_DELETE

getKeyCODe() 10
getKeyChar()
getKeyText(int key)
isActionKey()

MouseEvent

MOUSE_CLICKED
MOUSE_ENTERED
MOUSE_EXITED
MOUSE_PRESSED
MOUSE_RELEASED
MOUSE_WHEEL
MOUSE_DRAG
MOUSE_MOVED

getX()
getY()
getPoint()
getClickCount()
getButton()

BUTTON1
BUTTON2
BUTTON3

MouseWHeelEvent

WHEEL_BLOCK_SCROLL
WHEEL_UNIT_SCROLL

getScrollAmount()
getScrollType()
getWheelRotation()

TextEvent

TEXT_VALUE_CHANGED

TextEvent(Component kaynak,int tip)

WindowEvent

WINDOW_ACIVATED
WINDOW_DEACTIVATED
WINDOW_OPENED
WINDOW_CLOSED
WINDOW_CLOSING
WINDOW_ICONFIED
WINDOW_DEICONFIED
WINDOW_GAINED_FOCUS
WINDOW_LOST_FOCUS
WINDOW_STATE_CHANGED

getWindow()
getOldState()
getNewState()
*/

/*

ActionListener

actionPerformed(ActionEvent a)

AdjustmentListener

adjustmentValeuChanged(AdjustmenEvent a)

ComponentListener

componentResized()
componentMoved()
componentshown()
componentHidden()

ContainerListener

containerAdded()
containerRemoved()

FocusListener

focusGained()
focusLost()

ItemListener

itemStateChanged()

KeyListener

keyPressed()
keyReleased()
keyType()

MouseListener

mouseClicked()
mouseReleased()
mouseEntered()
mouseExited()
mousePressed()

MouseMotionListener

mouseDragged()
mouseMoved()

MouseWheelListener

mouseWheelMoved()

TextListener

textChanged()

windowFocusListener

windowGainedFocus()
windowLostFocus()

windowListener

windowActivated()
windowDeActivated()
windowClosed()
windowOpened()
windowClosing()
windowIconfied()
windowDeIconfied()

*/