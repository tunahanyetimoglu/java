package soyutOrnek;

public class soyutAlt {

public abstract class ustSoyut{
	public abstract void ustSoyut();
}
	public abstract class ustSoyut2 extends ustSoyut{
		public abstract void ustSoyut2();
	}
	
	class altSinif2{
		
	}
	
	class altSinif extends ustSoyut2{

		@Override
		public void ustSoyut2() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void ustSoyut() {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
