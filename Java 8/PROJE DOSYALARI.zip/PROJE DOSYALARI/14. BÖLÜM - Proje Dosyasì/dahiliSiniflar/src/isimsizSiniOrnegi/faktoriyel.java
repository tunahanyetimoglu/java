package isimsizSiniOrnegi;

public interface faktoriyel {
	public double hesap();
}
