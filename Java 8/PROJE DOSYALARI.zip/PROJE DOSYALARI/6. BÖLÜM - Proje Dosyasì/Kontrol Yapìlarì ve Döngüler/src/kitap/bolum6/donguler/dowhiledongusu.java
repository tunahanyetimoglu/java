package kitap.bolum6.donguler;

public class dowhiledongusu 
{
	public static void main(String[] args) 
	{
		int sayi=10;
		do
		{
			System.out.println("D�ng� �al��t�");
		}while(sayi>50);
	}

}
